export default {
  MuiToggleButtonGroup: {
    styleOverrides: {
      root: {
        borderRadius: 4
      }
    }
  },
  MuiToggleButton: {
    styleOverrides: {
      root: {
        borderRadius: 4
      }
    }
  }
}
